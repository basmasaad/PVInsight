#!/usr/bin/env python
# coding: utf-8

# In[2]:


#Libraries needed


import numpy as np 
import pandas as pd 
from scipy import stats
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

def ghi_p_zeros(data1,GHI_column,Power_column):
    l1 = list((data1[(data1[GHI_column] >= 200) & (data1[Power_column] == 0.0)]).index)
    l2 = list((data1[(data1[GHI_column] == 0.0) & (data1[Power_column] > 0)]).index)
    data2 = data1.drop(l1,axis=0)
    data3 = data2.drop(l2,axis=0)
    il=data3.index
    return il
def z_scores(data1,pas_g,GHI_column,Power_column,Version_column):
    IL_idx=[]
    ming=data1[GHI_column].min()
    maxg=data1[GHI_column].max()
    ghi_interval = np.arange(ming, maxg + pas_g, pas_g)
    for arr in (data1[Version_column].unique()):
        dt=data1[data1[Version_column]==arr]
        
        for i in range(len(ghi_interval) - 1):
            min_v_ghi, max_v_ghi = ghi_interval[i], ghi_interval[i + 1]
            df_ghi = dt[(dt[GHI_column] >= min_v_ghi) &
                                       (dt[GHI_column] < max_v_ghi)]
            
            #df_ghi['Active_Power_r'] = df_ghi['Active_Power'].round(1)
            #dsp = df_ghi['Active_Power_r'].drop_duplicates(keep='first', inplace=False)
            ZC=stats.zscore(df_ghi[Power_column])
            q1 = np.percentile(abs(ZC), 25)
            q3 = np.percentile(abs(ZC), 75)
            iqr = q3 - q1
            upper_bound = q3 + 1.5 * iqr
            #ZC1=stats.zscore(df_ghi['Active_Power'])
            df_ghi['ZC']=ZC
            il=list((df_ghi[df_ghi['ZC']>=-upper_bound]).index)
            
            IL_idx.extend(il)
   
    return IL_idx

def dbscan_func(data1,GHI_column,Power_column,Version_column):
    eps=[0.05,0.1,0.15,0.2]
    min_s=[100,150,200,250,300]
    percentages=[]
    cols=[GHI_column,Power_column]
    IL=[]
    for i in panels_to_keep:
        #print('Version: ',i)
        break_out = False
        features = data1[data1[Version_column]==i]
        #print(features.shape)
        if (features.shape[0]!=0):
            #features = features[cols]
            # Standardize the features
            scaler = StandardScaler()
            features_scaled = scaler.fit_transform(features[cols])
            for e in eps:
                for m in min_s:
            # Apply DBSCAN
            
                    dbscan = DBSCAN(eps=e, min_samples=m)
                    labels = dbscan.fit_predict(features_scaled)
                    features['labels']=labels
                    s=features[features['labels']!=-1].shape[0]
                    #print(s,'---',(s*100)/features.shape[0])
                    
                    if (len(features['labels'].unique())==2):
                        break_out = True
                        break
                if (break_out == True):     
                    break
            # Apply DBSCAN
            percentages.append((s*100)/features.shape[0])
            idx=list(features[features['labels']!=-1].index)
            IL.extend(idx)
            #print('Parameters of DBSCAN: ',e, m, features['labels'].unique())
        
    return IL,percentages

def calculate_slop(ghimin1,ghimin2,pmin1,pmin2):
    
    a=(pmin2-pmin1)/(ghimin2-ghimin1)
    b=pmin1-(a*ghimin1)
    return a,b
def interpolation_func(df,IL,pas_g,f,GHI_column,Power_column,Version_column):
    columns = [Version_column, 'GHI_start', 'GHI_end','a1','b1','a2','b2']
    df_borders = pd.DataFrame(columns=columns)
    a=b=c=d=0
    thebool=0
    OL_to_add=[]
    IL_to_keep=[]
    
    df['Active_Power_r'] = df[Power_column].round(0)
    df['Global_Horizontal_Radiation_r'] = df[GHI_column].round(0)
    df_IL = df.loc[IL]
    df_OL = df.drop(index=IL)
    minp = df_IL[Power_column].min()
    maxg = df_IL[GHI_column].max()
    maxp = df_IL[Power_column].max()
    ming = df_IL[GHI_column].min()

    ghi_interval = np.arange(ming, maxg + pas_g, pas_g)
    
    for i in range(len(ghi_interval) - 1,0,-1):
        arr=[]
        arr.extend(df[Version_column].unique())
        if (i==len(ghi_interval) - 1):
        
            max_v_ghi, min_v_ghi = ghi_interval[i], ghi_interval[i - 1]

            dfghi=df_IL[(df_IL['Global_Horizontal_Radiation_r'] >= min_v_ghi) &
                        (df_IL['Global_Horizontal_Radiation_r'] <= max_v_ghi)]
            min_ghi=dfghi['Global_Horizontal_Radiation_r'].min()
            max_ghi=dfghi['Global_Horizontal_Radiation_r'].max()
            min1_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==max_ghi]['Active_Power_r'].min()
            max1_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==max_ghi]['Active_Power_r'].max()
            max2_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi]['Active_Power_r'].max()
            min2_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi]['Active_Power_r'].min()
            IL_max_ghi=max_ghi
            IL_max_power=max1_v_p
            IL_min_power=min1_v_p
            
        else:
            max_v_ghi, min_v_ghi = min_ghi, ghi_interval[i - 1]
            dfghi=df_IL[(df_IL['Global_Horizontal_Radiation_r'] >= min_v_ghi) &
                            (df_IL['Global_Horizontal_Radiation_r'] <= max_v_ghi)]
            min_ghi=dfghi['Global_Horizontal_Radiation_r'].min()
            max_ghi=dfghi['Global_Horizontal_Radiation_r'].max()
        
            min1_v_p=min2_v_p
            max1_v_p=max2_v_p
            max2_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi]['Active_Power_r'].max()
            min2_v_p=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi]['Active_Power_r'].min()
        arr.extend([max_ghi])
        arr.extend([min_ghi])
        
        if (abs(min1_v_p-min2_v_p)>f):
            df_pv=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi].sort_values(by=['Active_Power_r'],ascending=True)
            df_pv=df_pv.reset_index(drop=True)
            for i in df_pv.index:
                if (abs(min1_v_p-(df_pv['Active_Power_r'][i]))<=f):
                    min2_v_p=df_pv['Active_Power_r'][i]
                    break
        if (abs(max1_v_p-max2_v_p)>f):
            df_pv=dfghi[dfghi['Global_Horizontal_Radiation_r']==min_ghi].sort_values(by=['Active_Power_r'],ascending=False)
            for i in df_pv.index:
                if (abs(max1_v_p-df_pv['Active_Power_r'][i])<=f):#best panels efficiency is 23%
                    max2_v_p=df_pv['Active_Power_r'][i]
                    break
        
        a1,b1=calculate_slop(max_ghi,min_ghi,min1_v_p,min2_v_p)
        a2,b2=calculate_slop(max_ghi,min_ghi,max1_v_p,max2_v_p)
        arr.extend([a1])
        arr.extend([b1])
        arr.extend([a2])
        arr.extend([b2])
        df_borders = df_borders.append({Version_column: arr[0], 'GHI_start': arr[1], 'GHI_end': arr[2],'a1':arr[3],'b1':arr[4],'a2':arr[5],'b2':arr[6]}, ignore_index=True)
        #df_OL_int=df_OL[(df_OL['Global_Horizontal_Radiation'] >= min_v_ghi) & (df_OL['Global_Horizontal_Radiation'] <= max_v_ghi)]
        #df_IL_int=df_IL[(df_IL['Global_Horizontal_Radiation'] >= min_v_ghi) & (df_IL['Global_Horizontal_Radiation'] <= max_v_ghi)]
        dfg=df[(df['Global_Horizontal_Radiation_r'] >= min_ghi) & (df['Global_Horizontal_Radiation_r'] <= max_ghi)]
        
        for j in dfg.index:
            power=dfg['Active_Power_r'][j]
            
            d1=(dfg['Global_Horizontal_Radiation_r'][j]*a1)+b1
           
            d2=(dfg['Global_Horizontal_Radiation_r'][j]*a2)+b2
            
            if((power>=d1)&(power<=d2)):
                       
                    OL_to_add.append(j)
       
        if ((min_ghi<=1000)&(thebool==0)):
            #print('found')
            a=a1
            b=b1
            c=a2
            d=b2
            thebool=1
    
    return OL_to_add,a,b,c,d,df_borders

def linear_interpol(df,a1,b1,a2,b2):
    #data after the max in DBSCAN will be preserved because in the max of GHI the panel efficiency may decrease depending on the cofficient of temp as well as we may have greate effic
   
    OL_to_add=[]
    dfg=df[(df['Global_Horizontal_Radiation_r'] >= 1000)]
   
    for j in dfg.index:
        power=dfg['Active_Power_r'][j]
        
        d1=(dfg['Global_Horizontal_Radiation_r'][j]*a1)+b1
           
        d2=(dfg['Global_Horizontal_Radiation_r'][j]*a2)+b2
            
        if((power>=d1)&(power<=d2)):
            OL_to_add.append(j)
  
    return OL_to_add
def check_inliers_outliers(df_borders,row,pv_power,GHI_column,Power_column,Version_column):
    inl=-1
    ghi=row[GHI_column]
    arr=row[Version_column]
    df_c=df_borders[(df_borders[Version_column]==arr)]
    df_c=df_c.reset_index(drop=True)
    max_ghi=df_c['GHI_end'].max()
    ghi_interval = np.arange(0, max_ghi + 100, 100)
    for i in range(len(ghi_interval) - 1,0,-1):
        max_v_ghi, min_v_ghi = ghi_interval[i], ghi_interval[i - 1]
        if (min_v_ghi<=ghi<max_v_ghi):
            a1=df_c[df_c['GHI_end']==min_v_ghi]['a1'].item()
            b1=df_c[df_c['GHI_end']==min_v_ghi]['b1'].item()
            a2=df_c[df_c['GHI_end']==min_v_ghi]['a2'].item()
            b2=df_c[df_c['GHI_end']==min_v_ghi]['b2'].item()
            d1=(ghi*a1)+b1
            d2=(ghi*a2)+b2
            if d1 <= pv_power <= d2:
                inl = 0
    if (ghi>=1000):
        a1=df_c[df_c['GHI_end']==1000]['a1'].item()
        b1=df_c[df_c['GHI_end']==1000]['b1'].item()
        a2=df_c[df_c['GHI_end']==1000]['a2'].item()
        b2=df_c[df_c['GHI_end']==1000]['b2'].item()
        d1=(ghi*a1)+b1
        d2=(ghi*a2)+b2
        if d1 <= pv_power <= d2:
            inl = 0

        
        
        
    return inl
#USE OF THE FUNCTION
def detect_outliers(data1,Version_column,GHI_column,Power_column,Rating_column):
    data1=data1.reset_index(drop=True)
    ilzero=ghi_p_zeros(data1,GHI_column,Power_column)
    Dzeros=data1.loc[ilzero]
    print('Dzeros shape : ',Dzeros.shape)
    IL_ZC=z_scores(Dzeros,100,GHI_column,Power_column,Version_column)
    data_ZC=Dzeros.loc[IL_ZC]
    il_t,percentages=dbscan_func(data_ZC,GHI_column,Power_column,Version_column)
    print('data_before db shape : ',data_ZC.shape)
    data1_db=data_ZC.loc[il_t]
    data1_db=data1_db.reset_index(drop=True)
    print('data_after db shape : ',data1_db.shape)
    columns = [Version_column, 'GHI_start', 'GHI_end','a1','b1','a2','b2']
    df_borders = pd.DataFrame(columns=columns)
    inliers = data1.loc[il_t]
    outliers = data1.drop(il_t)
    print('inliers shape : ',inliers.shape)
    print('outliers shape : ',outliers.shape)
    inliers_all=[]
    
    for arr in (data1[Version_column].unique()):
        dt=data1[data1[Version_column]==arr]
        dt_in=inliers[inliers[Version_column]==arr]
        dt_out=outliers[outliers[Version_column]==arr]
        print('dt_in shape : ',dt_in.shape)
        print('dt_out shape : ',dt_out.shape)
        il=dt_in.index
        eff=round((dt[Rating_column].max())/10,0)
        inliers_to_keep,a,b,c,d,dfb= interpolation_func(dt,il,100,eff,GHI_column,Power_column,Version_column)
        print('inliers to keep : ',len(inliers_to_keep))
        df_borders=pd.concat([df_borders, dfb], ignore_index=True)
        inlier_interpol=linear_interpol(dt,a,b,c,d)
        inliers_all.extend(inliers_to_keep)
        inliers_all.extend(inlier_interpol)
#         inliers_to_keep_dt=dt.loc[inliers_to_keep]
#         inliers_interpol_dt=dt.loc[inlier_interpol]

        unique_inliers = list(set(inliers_all)) 
        
    return df_borders, unique_inliers

